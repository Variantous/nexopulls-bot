
import os
from dotenv import load_dotenv
load_dotenv()
token = os.getenv("TELEGRAM_BOT_TOKEN")
print(f"Token configured: {'Yes' if token else 'No'}")
print(f"Seller: {os.getenv('EBAY_SELLER_USERNAME')}")
print("Ready to deploy! Run: python bot.py")
