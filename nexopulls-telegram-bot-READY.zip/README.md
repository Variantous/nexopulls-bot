# NexoPulls Telegram Bot - eBay Connected

Fully functional Telegram bot that syncs live with https://www.ebay.com/usr/nexopulls

### Features
- 🛍️ Live inventory from eBay (auto-sync every 30 min)
- 📸 Photos, prices, buy buttons -> direct to eBay checkout
- 🔍 /search pokemon, titanium, etc
- 🔔 Subscribe to new drops (DM alerts)
- 📢 Auto-post to Telegram Channel (@nexopulls_deals) when you list new item
- Works with OR without eBay API keys (scraper fallback)

### 1. Create Telegram Bot
1. Open Telegram, search @BotFather
2. Send /newbot -> Name: NexoPulls Shop -> Username: nexopulls_bot (must end in bot)
3. Copy the token (looks like 123456:ABC-DEF1234...)
4. (Optional) Create a channel @nexopulls_deals, add your bot as Admin

### 2. eBay API (recommended but optional)
- Go to developer.ebay.com -> Create account -> Create App -> Get Client ID + Secret
- This gives you 5000 calls/day, faster, more reliable
- If you skip this, bot uses scraping (still works)

### 3. Deploy (choose one)

#### Option A: Run locally (5 min)
```bash
pip install -r requirements.txt
cp .env.example .env
# edit .env with your tokens
python bot.py
```

#### Option B: Free 24/7 hosting - Railway / Render
- Push this folder to GitHub
- Railway.app -> New Project -> Deploy from GitHub
- Add env variables from .env.example
- It auto-runs bot.py

#### Option C: VPS
```bash
nohup python bot.py &
```

### 4. .env Setup
```
TELEGRAM_BOT_TOKEN=123456:ABC...
EBAY_CLIENT_ID=YourEbayId-xxxx
EBAY_CLIENT_SECRET=YourSecret
EBAY_SELLER_USERNAME=nexopulls
TELEGRAM_CHANNEL_ID=@nexopulls_deals
CHECK_INTERVAL_MINUTES=30
```

### Commands for Users
- /start - Welcome
- /inventory - Browse
- /search <term> - Search
- /new - Latest 5
- /alerts - Subscribe toggle

### How auto-sync works
Every 30 min, bot fetches ebay.com/usr/nexopulls, compares to known_items.json.
If new listing detected:
- DMs all subscribers
- Posts to your Telegram Channel with Buy button

No orders processed in Telegram - keeps you eBay-compliant. Buyer clicks -> eBay checkout -> you get order on eBay as usual.

Want me to add Stripe checkout inside Telegram? Let me know.
