# FINAL SETUP - 2 MINUTES

## You are 1 step away

I've built everything. You just need a Telegram Bot Token.

### Step 1: Get Token (30 sec)
1. Open Telegram app
2. Search for @BotFather (verified checkmark)
3. Send: /newbot
4. Name: NexoPulls Shop
5. Username: nexopulls_shop_bot (must end in bot, try variants if taken)
6. BotFather will reply with token like: 1234567890:AAH... copy it

### Step 2: Paste Token
Open .env file in this folder and replace PASTE_YOUR_TOKEN_HERE with your token.
Save.

### Step 3: Run
Double-click run.bat (Windows) or run.sh (Mac/Linux)
OR deploy free 24/7:

Railway (easiest):
- Go to railway.app -> Login with GitHub
- New Project -> Deploy from GitHub -> Select this repo
- Variables -> Add TELEGRAM_BOT_TOKEN = your token
- Add EBAY_SELLER_USERNAME = nexopulls
- Deploy!

Your bot will be live instantly.

### Test it
In Telegram, search for your bot username and send /start

No eBay API keys needed - scraper mode works immediately.
Add them later for faster sync in eBay developer portal.

Need help? Send me your token (temporarily) and I can test the connection for you.
