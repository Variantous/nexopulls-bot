import os
import json
import asyncio
from datetime import datetime
from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes, MessageHandler, filters
from telegram.constants import ParseMode
from ebay_client import EbayClient

load_dotenv()

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
CHANNEL_ID = os.getenv("TELEGRAM_CHANNEL_ID")  # e.g. @nexopulls_deals or -1001234567890
SELLER = os.getenv("EBAY_SELLER_USERNAME", "nexopulls")
CHECK_INTERVAL = int(os.getenv("CHECK_INTERVAL_MINUTES", "30"))
ITEMS_PER_PAGE = int(os.getenv("ITEMS_PER_PAGE", "5"))

DATA_FILE = "known_items.json"
SUBSCRIBERS_FILE = "subscribers.json"

ebay = EbayClient()

def load_json(path, default):
    try:
        with open(path, "r") as fp:
            return json.load(fp)
    except:
        return default

def save_json(path, data):
    with open(path, "w") as fp:
        json.dump(data, fp, indent=2)

def format_item_text(item, idx=None):
    title = item.get("title","No title")[:120]
    price = item.get("price","?")
    if isinstance(price, (int,float)):
        price_str = f"${price}"
    else:
        price_str = str(price)
        if "$" not in price_str:
            price_str = f"${price_str}" if price_str.replace(".","",1).isdigit() else price_str
    
    header = f"*{idx}. {title}*" if idx else f"*{title}*"
    text = f"{header}\n"
    text += f"💰 Price: `{price_str}` {item.get('currency','USD')}\n"
    if item.get("condition"):
        text += f"📦 Condition: {item.get('condition')}\n"
    text += f"\n🔗 [View on eBay]({item.get('url')})\n"
    text += f"_Seller: {SELLER} • 100% Positive Feedback_"
    return text

def get_item_keyboard(item):
    buttons = []
    if item.get("url"):
        buttons.append([InlineKeyboardButton("🛒 Buy on eBay", url=item["url"])])
    buttons.append([InlineKeyboardButton("🔍 More from store", callback_data="page_0")])
    return InlineKeyboardMarkup(buttons)

def get_pagination_keyboard(page, total_pages, prefix="page_"):
    buttons = []
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton("⬅️ Prev", callback_data=f"{prefix}{page-1}"))
    if page < total_pages - 1:
        nav.append(InlineKeyboardButton("Next ➡️", callback_data=f"{prefix}{page+1}"))
    if nav:
        buttons.append(nav)
    buttons.append([InlineKeyboardButton("🔄 Refresh", callback_data=f"{prefix}{page}"),
                    InlineKeyboardButton("🏠 Home", callback_data="home")])
    return InlineKeyboardMarkup(buttons)

# --- Handlers ---

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    text = f"""👋 Hey {user.first_name}! Welcome to **NexoPulls Official Bot**!

I\'m directly connected to the eBay store: `ebay.com/usr/{SELLER}`

Follow @nexopulls everywhere! We buy and sell all things Pokémon! Plus curated trending finds.

**What I can do:**
/inventory - Browse current listings ({SELLER} has 21+ items sold, 100% feedback)
/search <keyword> - Search store (e.g. /search pokemon)
/new - Latest drops
/alerts - Get notified when new items list
/channel - Setup auto-posting to your Telegram channel

🛒 Every buy button takes you straight to eBay checkout - safe & secure.

_Built for nexopulls - consignment available, DM on eBay_"""
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🛍️ Browse Inventory", callback_data="page_0")],
        [InlineKeyboardButton("🆕 Latest Drops", callback_data="latest"),
         InlineKeyboardButton("🔔 Alerts", callback_data="alerts")],
        [InlineKeyboardButton("📦 View eBay Store", url=f"https://www.ebay.com/usr/{SELLER}")]
    ])
    await update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=kb)

async def inventory(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await send_page(update, context, page=0)

async def send_page(update: Update, context: ContextTypes.DEFAULT_TYPE, page=0, items=None):
    chat_id = update.effective_chat.id if update.effective_chat else update.callback_query.message.chat_id
    is_callback = update.callback_query is not None
    
    if items is None:
        await context.bot.send_chat_action(chat_id=chat_id, action="typing")
        status_msg = None
        if is_callback:
            try:
                await update.callback_query.answer("🔄 Fetching from eBay...")
            except: pass
        else:
            status_msg = await context.bot.send_message(chat_id, "⏳ Pulling live inventory from eBay...")

        items = await ebay.get_items(limit=50)
        context.user_data["last_items"] = items
        
        if status_msg:
            try: await status_msg.delete()
            except: pass

    if not items:
        txt = "😔 Couldn\'t fetch items right now. eBay might be rate-limiting. Try again in 1 min or check directly:\nhttps://www.ebay.com/usr/nexopulls"
        if is_callback:
            await update.callback_query.message.reply_text(txt)
        else:
            await update.message.reply_text(txt)
        return

    total_pages = (len(items) + ITEMS_PER_PAGE - 1)//ITEMS_PER_PAGE
    page = max(0, min(page, total_pages-1))
    start = page*ITEMS_PER_PAGE
    chunk = items[start:start+ITEMS_PER_PAGE]

    for i, item in enumerate(chunk, start=start+1):
        try:
            if item.get("image"):
                await context.bot.send_photo(
                    chat_id=chat_id,
                    photo=item["image"],
                    caption=format_item_text(item, i),
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=get_item_keyboard(item)
                )
            else:
                await context.bot.send_message(
                    chat_id=chat_id,
                    text=format_item_text(item, i),
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=get_item_keyboard(item),
                    disable_web_page_preview=False
                )
            await asyncio.sleep(0.4)
        except Exception as e:
            print(f"Send error: {e}")
            await context.bot.send_message(chat_id, format_item_text(item,i), parse_mode=ParseMode.MARKDOWN, reply_markup=get_item_keyboard(item))

    # pagination footer
    footer = f"Page {page+1}/{total_pages} • {len(items)} live listings • Updated {datetime.now().strftime('%H:%M')}"
    if is_callback:
        await update.callback_query.message.reply_text(footer, reply_markup=get_pagination_keyboard(page, total_pages))
    else:
        await context.bot.send_message(chat_id, footer, reply_markup=get_pagination_keyboard(page, total_pages))

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    data = query.data
    if data.startswith("page_"):
        page = int(data.split("_")[1])
        items = context.user_data.get("last_items")
        await send_page(update, context, page=page, items=items)
        await query.answer()
    elif data == "latest":
        items = await ebay.get_items(limit=10)
        context.user_data["last_items"] = items
        await query.answer("Latest 5 drops")
        await send_page(update, context, page=0, items=items[:5])
    elif data == "alerts":
        await alerts(update, context)
        await query.answer()
    elif data == "home":
        await query.answer()
        await start_callback(update, context)

async def start_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = f"""🏠 **NexoPulls Bot Menu**

/inventory - Browse all
/search pokemon - Search
/new - Newest items
/alerts - Notifications"""
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🛍️ Browse", callback_data="page_0")],
        [InlineKeyboardButton("📦 eBay Store", url=f"https://www.ebay.com/usr/{SELLER}")]
    ])
    await update.callback_query.message.reply_text(text, parse_mode=ParseMode.MARKDOWN, reply_markup=kb)

async def search_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Usage: /search <keyword>\nExample: /search titanium pan or /search pokemon")
        return
    q = " ".join(context.args).lower()
    await update.message.reply_text(f"🔍 Searching for `{q}` in nexopulls store...", parse_mode=ParseMode.MARKDOWN)
    items = await ebay.get_items(limit=50)
    filtered = [it for it in items if q in (it.get("title","").lower())]
    if not filtered:
        await update.message.reply_text(f"No results for `{q}`. Try /inventory to see everything.", parse_mode=ParseMode.MARKDOWN)
        return
    context.user_data["last_items"] = filtered
    await send_page(update, context, page=0, items=filtered)

async def new_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🆕 Fetching newest drops...")
    items = await ebay.get_items(limit=10)
    context.user_data["last_items"] = items
    await send_page(update, context, page=0, items=items[:5])

async def alerts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id if update.effective_chat else update.callback_query.message.chat_id
    subs = load_json(SUBSCRIBERS_FILE, [])
    if chat_id in subs:
        kb = InlineKeyboardMarkup([[InlineKeyboardButton("🔕 Unsubscribe", callback_data="unsub")]])
        txt = "🔔 You ARE subscribed! I\'ll DM you when nexopulls lists something new.\n\nWe check every 30 minutes."
    else:
        kb = InlineKeyboardMarkup([[InlineKeyboardButton("🔔 Subscribe to new drops", callback_data="sub")]])
        txt = "🔕 You\'re not subscribed yet.\n\nSubscribe to get instant DMs when new items drop in the eBay store!"

    if update.callback_query:
        await update.callback_query.message.reply_text(txt, parse_mode=ParseMode.MARKDOWN, reply_markup=kb)
    else:
        await update.message.reply_text(txt, parse_mode=ParseMode.MARKDOWN, reply_markup=kb)

async def sub_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    chat_id = query.message.chat_id
    subs = load_json(SUBSCRIBERS_FILE, [])
    if query.data == "sub":
        if chat_id not in subs:
            subs.append(chat_id)
            save_json(SUBSCRIBERS_FILE, subs)
        await query.answer("Subscribed! 🔔")
        await query.message.reply_text("✅ Subscribed! You\'ll get notified for every new listing.")
    elif query.data == "unsub":
        if chat_id in subs:
            subs.remove(chat_id)
            save_json(SUBSCRIBERS_FILE, subs)
        await query.answer("Unsubscribed")
        await query.message.reply_text("🔕 Unsubscribed from new drop alerts.")

# Auto-check job
async def check_new_items_job(context: ContextTypes.DEFAULT_TYPE):
    print(f"[{datetime.now()}] Checking for new items...")
    known = load_json(DATA_FILE, {})
    current_items = await ebay.get_items(limit=50)
    if not current_items:
        return
    current_ids = {it.get("id") or it.get("url") for it in current_items}
    known_ids = set(known.keys())
    new_ids = current_ids - known_ids

    if new_ids and known:  # skip first run
        new_items = [it for it in current_items if (it.get("id") or it.get("url")) in new_ids]
        print(f"Found {len(new_items)} new items")
        # Notify subscribers
        subs = load_json(SUBSCRIBERS_FILE, [])
        for chat_id in subs:
            for it in new_items[:3]:
                try:
                    text = f"🚨 *NEW DROP* at NexoPulls!\n\n" + format_item_text(it)
                    await context.bot.send_photo(
                        chat_id=chat_id,
                        photo=it.get("image") or "https://i.ebayimg.com/images/g/placeholder/s-l500.jpg",
                        caption=text,
                        parse_mode=ParseMode.MARKDOWN,
                        reply_markup=get_item_keyboard(it)
                    )
                    await asyncio.sleep(0.5)
                except Exception as e:
                    print(f"Notify error {chat_id}: {e}")
        # Post to channel if set
        if CHANNEL_ID and new_items:
            for it in new_items[:5]:
                try:
                    await context.bot.send_photo(
                        chat_id=CHANNEL_ID,
                        photo=it.get("image") or it.get("url"),
                        caption=f"🆕 *{it.get('title')[:100]}*\n💰 {it.get('price')} | [Buy Now]({it.get('url')})\n\n#nexopulls #ebayfinds",
                        parse_mode=ParseMode.MARKDOWN,
                        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🛒 Buy on eBay", url=it.get("url"))]])
                    )
                except Exception as e:
                    print(f"Channel post error: {e}")

    # Update known
    new_known = { (it.get("id") or it.get("url")): {"title": it.get("title"), "seen": datetime.now().isoformat()} for it in current_items}
    save_json(DATA_FILE, new_known)

def main():
    if not BOT_TOKEN:
        print("ERROR: Set TELEGRAM_BOT_TOKEN in .env")
        return
    app = Application.builder().token(BOT_TOKEN).build()
    
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("inventory", inventory))
    app.add_handler(CommandHandler("shop", inventory))
    app.add_handler(CommandHandler("search", search_cmd))
    app.add_handler(CommandHandler("new", new_cmd))
    app.add_handler(CommandHandler("alerts", alerts))
    app.add_handler(CommandHandler("channel", alerts))

    app.add_handler(CallbackQueryHandler(button_handler, pattern="^(page_|latest|alerts|home)"))
    app.add_handler(CallbackQueryHandler(sub_handler, pattern="^(sub|unsub)$"))

    # Job queue - check every 30 min
    job_queue = app.job_queue
    job_queue.run_repeating(check_new_items_job, interval=CHECK_INTERVAL*60, first=10)

    print(f"Bot running for {SELLER}... Press Ctrl+C to stop")
    print(f"Check interval: {CHECK_INTERVAL} min | Channel: {CHANNEL_ID or 'not set'}")
    app.run_polling()

if __name__ == "__main__":
    main()
