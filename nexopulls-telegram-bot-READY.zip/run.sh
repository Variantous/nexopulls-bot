#!/bin/bash
python -m pip install -r requirements.txt
python bot.py
