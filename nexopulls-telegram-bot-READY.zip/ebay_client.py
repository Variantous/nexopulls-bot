import os
import time
import aiohttp
import asyncio
from bs4 import BeautifulSoup
import json
from typing import List, Dict, Optional
import base64

class EbayClient:
    def __init__(self, client_id=None, client_secret=None, seller_username="nexopulls", marketplace="EBAY_US"):
        self.client_id = client_id or os.getenv("EBAY_CLIENT_ID")
        self.client_secret = client_secret or os.getenv("EBAY_CLIENT_SECRET")
        self.seller_username = seller_username or os.getenv("EBAY_SELLER_USERNAME", "nexopulls")
        self.marketplace = marketplace
        self.token = None
        self.token_expires = 0
        self.base_url = "https://api.ebay.com"

    async def _get_oauth_token(self, session: aiohttp.ClientSession):
        if self.token and time.time() < self.token_expires - 60:
            return self.token
        if not self.client_id or not self.client_secret:
            return None
        
        auth = base64.b64encode(f"{self.client_id}:{self.client_secret}".encode()).decode()
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Authorization": f"Basic {auth}"
        }
        data = {
            "grant_type": "client_credentials",
            "scope": "https://api.ebay.com/oauth/api_scope"
        }
        try:
            async with session.post(f"{self.base_url}/identity/v1/oauth2/token", headers=headers, data=data) as resp:
                if resp.status == 200:
                    j = await resp.json()
                    self.token = j["access_token"]
                    self.token_expires = time.time() + j.get("expires_in", 7200)
                    return self.token
        except Exception as e:
            print(f"OAuth error: {e}")
        return None

    async def fetch_via_api(self, limit=50) -> List[Dict]:
        """Use official Browse API - filters by seller"""
        if not self.client_id:
            return []
        async with aiohttp.ClientSession() as session:
            token = await self._get_oauth_token(session)
            if not token:
                return []
            headers = {
                "Authorization": f"Bearer {token}",
                "X-EBAY-C-MARKETPLACE-ID": self.marketplace
            }
            # Search by seller filter
            url = f"{self.base_url}/buy/browse/v1/item_summary/search"
            params = {
                "filter": f"sellers:{{{self.seller_username}}}",
                "limit": str(limit),
                "sort": "newlyListed"
            }
            try:
                async with session.get(url, headers=headers, params=params) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        items = data.get("itemSummaries", [])
                        return [self._normalize_api_item(it) for it in items]
                    else:
                        text = await resp.text()
                        print(f"eBay API {resp.status}: {text[:500]}")
            except Exception as e:
                print(f"API fetch error: {e}")
        return []

    def _normalize_api_item(self, it: Dict) -> Dict:
        return {
            "id": it.get("itemId"),
            "title": it.get("title"),
            "price": it.get("price", {}).get("value"),
            "currency": it.get("price", {}).get("currency", "USD"),
            "url": it.get("itemWebUrl"),
            "image": it.get("image", {}).get("imageUrl") or (it.get("thumbnailImages", [{}])[0].get("imageUrl") if it.get("thumbnailImages") else None),
            "condition": it.get("condition"),
            "shipping": it.get("shippingOptions", [{}])[0].get("shippingCost", {}).get("value") if it.get("shippingOptions") else None,
        }

    async def fetch_via_scraper(self, limit=50) -> List[Dict]:
        """Fallback: scrape seller page - works without API keys"""
        url = f"https://www.ebay.com/usr/{self.seller_username}"
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, headers=headers, timeout=15) as resp:
                    if resp.status != 200:
                        print(f"Scraper status {resp.status}")
                        return []
                    html = await resp.text()
                    soup = BeautifulSoup(html, "lxml")
                    items = []
                    # eBay's structure changes often - try multiple selectors
                    for card in soup.select("div.b-info__row, li.s-item, div.s-item")[:limit]:
                        try:
                            title_el = card.select_one("h3, .s-item__title, a.it-ttl")
                            price_el = card.select_one(".s-item__price, .notranslate, span.BOLD")
                            link_el = card.select_one("a[href*='/itm/']")
                            img_el = card.select_one("img")
                            if title_el and link_el:
                                items.append({
                                    "id": link_el.get("href", "").split("/itm/")[-1].split("?")[0][:20] if "/itm/" in link_el.get("href","") else title_el.get_text(strip=True)[:20],
                                    "title": title_el.get_text(strip=True),
                                    "price": price_el.get_text(strip=True) if price_el else "See eBay",
                                    "currency": "USD",
                                    "url": link_el.get("href") if link_el else url,
                                    "image": img_el.get("src") if img_el else None,
                                    "condition": "New",
                                    "shipping": None
                                })
                        except:
                            continue
                    # If new selector fails, parse JSON-LD
                    if not items:
                        for script in soup.find_all("script", type="application/ld+json"):
                            try:
                                data = json.loads(script.string)
                                if isinstance(data, dict) and "itemListElement" in data:
                                    for el in data["itemListElement"][:limit]:
                                        prod = el.get("item", {})
                                        items.append({
                                            "id": prod.get("sku") or prod.get("mpn") or str(len(items)),
                                            "title": prod.get("name"),
                                            "price": prod.get("offers", {}).get("price"),
                                            "currency": "USD",
                                            "url": prod.get("url") or prod.get("offers", {}).get("url"),
                                            "image": prod.get("image"),
                                            "condition": "New",
                                            "shipping": None
                                        })
                            except:
                                continue
                    return items[:limit]
        except Exception as e:
            print(f"Scraper error: {e}")
            return []

    async def get_items(self, limit=50) -> List[Dict]:
        # Try API first, fallback to scraper
        items = await self.fetch_via_api(limit)
        if items:
            print(f"Fetched {len(items)} via eBay API")
            return items
        print("API failed or no creds, using scraper fallback")
        return await self.fetch_via_scraper(limit)

# Demo test
if __name__ == "__main__":
    import asyncio
    client = EbayClient()
    async def test():
        items = await client.get_items(10)
        print(json.dumps(items, indent=2))
    asyncio.run(test())
